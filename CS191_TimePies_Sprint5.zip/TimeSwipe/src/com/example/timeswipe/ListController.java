package com.example.timeswipe;

import java.util.*;

public class ListController {
	public static void initList(){
		List.init(ListDao.read());
	}
	
	public static void addTaskToList(String name, String date){
		List.addTask(new ListTask(name, date));
		//save to text file, every time a task is added the list is saved
		ListDao.write(List.get());
	}
	
//	public static void sortList(){
//		ArrayList<Task> tasks = List.get();
//		
//		
//	}
	
	public static int compareDate(String d1, String d2){
		String[] dayMonYear1 = d1.split("/");
		String[] dayMonYear2 = d2.split("/");
		
		if(Integer.parseInt(dayMonYear1[2]) < Integer.parseInt(dayMonYear2[2]))
			return -1;
		if(Integer.parseInt(dayMonYear1[2]) > Integer.parseInt(dayMonYear2[2]))
			return 1;
		else{
			if(Integer.parseInt(dayMonYear1[1]) < Integer.parseInt(dayMonYear2[1]))
				return -1;
			if(Integer.parseInt(dayMonYear1[1]) > Integer.parseInt(dayMonYear2[1]))
				return 1;
			else{
				if(Integer.parseInt(dayMonYear1[0]) < Integer.parseInt(dayMonYear2[0]))
					return -1;
				if(Integer.parseInt(dayMonYear1[0]) > Integer.parseInt(dayMonYear2[0]))
					return 1;
				else
					return 0;
			}
		}
	}
}
