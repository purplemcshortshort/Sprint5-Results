package com.example.timeswipe;

import android.app.Activity;
import android.os.Bundle;

public class HelpActivity extends Activity{
	public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help_page);
   }
}
