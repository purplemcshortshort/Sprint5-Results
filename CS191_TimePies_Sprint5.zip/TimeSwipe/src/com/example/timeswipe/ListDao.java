package com.example.timeswipe;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.*;

import android.content.Context;
import android.os.Environment;

 
public class ListDao {
	public static Context context;

	public static ArrayList<ListTask> read(){
		ArrayList<ListTask> tasks = new ArrayList<ListTask>();
		
		tasks.add(new ListTask("192  presentation","30/01/2014"));
		tasks.add(new ListTask("180 MP","30/01/2014"));
		tasks.add(new ListTask("hslc pubmat","30/01/2014"));
		tasks.add(new ListTask("153 hw","31/01/2014"));
		tasks.add(new ListTask("145 me1","01/02/2014"));
		tasks.add(new ListTask("study 130","01/02/2014"));
		tasks.add(new ListTask("tk semplan","02/02/2014"));
		tasks.add(new ListTask("install adt","02/02/2014"));
		tasks.add(new ListTask("192 backlog","02/02/2014"));
		
	/*	try{
			FileInputStream fis = context.openFileInput("ListSource.txt");
			InputStreamReader isr = new InputStreamReader(fis);
			BufferedReader br = new BufferedReader(isr);
			
			try{
				String line; 
			    String[] taskDate;
			    while ((line = br.readLine()) != null) {
			    	taskDate = line.split(";;;");
			    	Task t = new Task(taskDate[0], taskDate[1]);
			    	tasks.add(t);
			    }	
			}catch(IOException e){
				e.printStackTrace();
			}
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}*/
		return tasks;
	}
	
	public static void write(ArrayList<ListTask> tasks){
		/*ArrayList<Task> tasks = new ArrayList<Task>();
		tasks.add(new Task("192  presentation","30 Jan 2014"));
		tasks.add(new Task("180 MP","30 Jan 2014"));
		tasks.add(new Task("hslc pubmat","30 Jan 2014"));
		tasks.add(new Task("153 hw","31 Jan 2014"));
		tasks.add(new Task("145 me1","1 Feb 2014"));
		tasks.add(new Task("study 130","1 Feb 2014"));
		tasks.add(new Task("tk semplan","2 Feb 2014"));
		tasks.add(new Task("install adt","2 Feb 2014"));*/
		
		try {
			FileOutputStream fou = context.openFileOutput("ListSource.txt", Context.MODE_WORLD_READABLE);
			OutputStreamWriter osw = new OutputStreamWriter(fou);
			
	      	try{
				int i, len = tasks.size();
				for(i = 0; i<len; i++){
					ListTask t = tasks.get(i);
					osw.write(t.getName() + ";;;" + t.getDate()+ "\n");
				}
	      		  
	      		osw.flush();
	      		osw.close();
	      		  
			}catch(IOException e){
				e.printStackTrace();
			}
	    }catch(FileNotFoundException e){
			e.printStackTrace();
	    }
	}
	 
}
