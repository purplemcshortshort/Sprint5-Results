/**
 * REVISED BSD LICENSE
 * Copyright (c) 2015, Patricia Kelly D. Co, Kenneth T. Otsuka, Mary Jane T. Rubio
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Patricia Kelly Co, Mary Jane T. Rubio, and 
 * Kenneth T. Otsuka BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * @author Patricia Kelly D. Co
 * @author Kenneth T. Otsuka
 * This is a course requirement for CS 192 Software Eng'g II under the supervision of 
 * Prof. Ma. Rowena C. Solamo of the Department of Computer Science, College of Engineering, 
 * University of the Philippines, Diliman for AY 2014-2015.
 */
/**
 * Code History
  * @version 1.0
 * @author Patricia Kelly D. Co
 * @since 2014-11-13
 * Initial code.
 * @version 1.1
 * @author Kenneth T. Otsuka
 * @since 2014-02-06
 * Added Set Time functionality.
 * @author Patricia Kelly D. Co
 * @since 2014-02-10
 * Changed Button setTimeButton, startButton, and resetButton to ImageButton.
 * Added an onClickListener for startButton. 
 * Changed the layout design.
 * @version 1.2
 * @author Kenneth T. Otsuka
 * @author Mary Jane T. Rubio
 * @since 2015-02-27
 * Added add task and reset functionalities.
 */
/**
 * Created on 2014-11-13
 * Developed by Purple McShortShort
 * Client Pink PlastiCS
 * The Boundary Class of the application.
 */

package com.example.timeswipe;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import android.support.v4.app.Fragment;
/**
 * Handles the displaying of all UI.  
 *
 */

public class PieScheduleUI extends Activity {
	
	private boolean[] isColorTaken;
	private boolean doubletap;
	private boolean simpletap;
	private Button addButton;
	private Button ccwButton;
	private Button cwButton;
    private Chronometer chronometer;
    private int[] colors;
    private int[] lightColors;
    private long clickStart;
    private long clickLast;
    private int clickCount;
    private EditText inputText;
    //private CountDownTimer countDown;
    private ImageButton resetButton;
    private ImageButton setTimeButton;
    private ImageButton startButton;
    private PieSchedule pieSchedule;
    private PieUI pie;
    private SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
    private TimePicker timePicker;
    
    private Context context;    
    
    /**
     * onCreate
     *  - This is the onCreate method that starts up the TimePies.
     * @since 2015-02-10
     * @param savedInstanceState Saves the state upon call
     * @return view
     * @exception InterruptedException
     */
    
    @Override
    public void onCreate(Bundle savedInstanceState){
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.activity_pie_ui);
    	context = this;
        PieScheduleDao.context = context;
        /* init pie schedule, create from source file*/
        pieSchedule = PieScheduleController.initPieSchedule();
        /* init the time displayed */
        chronometer = (Chronometer) findViewById(R.id.chronometer);
        long timeRem = pieSchedule.getRemTime().totalInMilliSec();
        if(timeRem >= 0)
        	chronometer.setText("" + timeFormat.format(timeRem)); 
        else
        	chronometer.setText("" + timeFormat.format(0));
        /* init button click listeners */
        addButton = (Button) findViewById(R.id.addButton);
        addButtonOnClickListeners();
        ccwButton = (Button) findViewById(R.id.ccwButton);
        ccwButtonOnClickListeners();
        ccwButton.setVisibility(View.GONE);
        cwButton = (Button) findViewById(R.id.cwButton);
        cwButtonOnClickListeners();
        cwButton.setVisibility(View.GONE);
        setTimeButton = (ImageButton) findViewById(R.id.setTimeButton);
        setTimeButtonOnClickListeners();
        startButton = (ImageButton) findViewById(R.id.startButton);
        startButtonOnClickListeners();
        resetButton = (ImageButton) findViewById(R.id.resetButton);
        resetButtonOnClickListeners();
        /* init the displayed pie */
        pie = (PieUI) findViewById(R.id.pie);
        drawPieSchedule();
        pieOnTouchListener();
        /* init available colors */
        initColors();
        clickCount = 0;
        doubletap = false;
        simpletap = false;
        clickLast = System.currentTimeMillis();
     }
    private void ccwButtonOnClickListeners(){
    	ccwButton.setOnClickListener(new Button.OnClickListener(){
			@Override
        	public void onClick(View v) {
				if(PieScheduleController.resizeSlice(pieSchedule, -1)){
		        	drawPieSchedule();
		    	}
		    	else{
		        	Toast.makeText(context, "Minimum slice size reached.", Toast.LENGTH_SHORT).show();	
		    	}
        	}
       	});
    }
    
    private void cwButtonOnClickListeners(){
    	cwButton.setOnClickListener(new Button.OnClickListener(){
			@Override
        	public void onClick(View v) {
				if(PieScheduleController.resizeSlice(pieSchedule, 1)){
		        	drawPieSchedule();
		    	}
		    	else{
		        	Toast.makeText(context, "Minimum slice size reached.", Toast.LENGTH_SHORT).show();	
		    	}
        	}
       	});
    }
    
    public static Bitmap getBitmapFromView(View view) {
        Bitmap returnedBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(),Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(returnedBitmap);
        Drawable bgDrawable =view.getBackground();
        if (bgDrawable!=null) 
            bgDrawable.draw(canvas);
        else 
            canvas.drawColor(Color.WHITE);
        view.draw(canvas);
        return returnedBitmap;
    }
    
    private void pieOnTouchListener(){
    	pie.setOnTouchListener(new OnTouchListener(){
            @Override
            public boolean onTouch (View v, MotionEvent event)
            {
                switch(event.getAction() & MotionEvent.ACTION_MASK)
                {
	                case MotionEvent.ACTION_DOWN:
	                	clickStart = System.currentTimeMillis();
	                    break;
	                case MotionEvent.ACTION_UP:
	                	int x = (int)event.getX();
	    	            int y = (int)event.getY();
	    	            
	    	    		Bitmap bitmap = getBitmapFromView(v);
	    	    		int color = bitmap.getPixel(x, y);
	    	            //int color = Color.parseColor("#"+Integer.toHexString(bitmap.getPixel(x, y)));

	    	       	 	
	    	            int index = PieScheduleController.getSliceWithColor(pieSchedule, color);
	    	            
	    	            //System.out.println("nasa PSUI pieTouch() yan natouch mo" + color + "   yan ay slice at index "+index);
	    	            //System.out.println(Integer.toHexString(color));
	    	       	 	
	    	            
	            		PieScheduleController.tempIndex = index;
	            		
	                    long clickDuration = System.currentTimeMillis() - clickStart;
	                    /* long press, wanting to rearrange*/
	                    if(clickDuration>300){
	                    	pieSchedule.getSlice(PieScheduleController.tempIndex1).setOriginalColor();
	                    	PieScheduleController.selectSlice(pieSchedule);
	                    	drawPieSchedule();
	                    	if(index == pieSchedule.getSize()-1){
	                    		cwButton.setVisibility(View.GONE);
			                	ccwButton.setVisibility(View.VISIBLE);
	                    	}
	                    	else if(index == 0){
	                    		cwButton.setVisibility(View.VISIBLE);
			                	ccwButton.setVisibility(View.GONE);
	                    	}
	                    	else{
	                    		cwButton.setVisibility(View.VISIBLE);
			                	ccwButton.setVisibility(View.VISIBLE);
	                    	}
	                    	PieScheduleController.tempIndex1 = index;
	                    	//Toast.makeText(getActivity().getApplicationContext(), "you are about to rearrange", Toast.LENGTH_SHORT).show();	
	                    	clickCount = 1;
	                    }
	                    else if(clickCount == 1){
	                    	//PieScheduleController.switchSlices(pieSchedule);
	                    	cwButton.setVisibility(View.GONE);
		                	ccwButton.setVisibility(View.GONE);
	                    	PieScheduleController.moveSlice(pieSchedule);
	                    	drawPieSchedule();
	                    	//Toast.makeText(getActivity().getApplicationContext(), "you are rearranging", Toast.LENGTH_SHORT).show();
	                    	clickCount = 0;
	                    }
	                    /* not long press then check task */
	                    else{
		    	            if(index >= 0){
		    	            	if(pieSchedule.isRunning()){
		    	            		//Toast.makeText(getActivity().getApplicationContext(), "go to checkTaskRunning", Toast.LENGTH_SHORT).show();
		    	            		checkTaskRunning();
		    	            	}
		    	            	else{
		    	    				checkTaskNotRunning();
		    	            	}
		    	            }
	                    }
	                    break;                 
                }
            return true;    
            }
    	});
    }
    
    /**
     * resetButtonOnClickListeners
     *  - Called when resetButton is clicked. Resets the entire pie schedule.
     * @since 2015-02-27
     * @return void
     * @param void 
     */
    private void resetButtonOnClickListeners(){
		resetButton.setOnClickListener(new Button.OnClickListener(){
			@Override
        	public void onClick(View v) {
				if(pieSchedule.isEmpty()){
					Toast.makeText(context, "Pie is empty.", Toast.LENGTH_SHORT).show();
 	                return;
				}
        		AlertDialog.Builder builder1 = new AlertDialog.Builder(v.getContext());
        		builder1.setMessage("Are you sure you want to reset the entire schedule?");
        		builder1.setCancelable(true);
        		
        		builder1.setPositiveButton("Yes",
        				new DialogInterface.OnClickListener() {
        			public void onClick(DialogInterface dialog, int id) {
        				PieScheduleController.reset(pieSchedule);
        				drawPieSchedule();
        				initColors();
        				chronometer.setText("" + timeFormat.format(0));
        			}
        		});
        		
        		builder1.setNegativeButton("No",
        				new DialogInterface.OnClickListener() {
        			public void onClick(DialogInterface dialog, int id) {
        				dialog.cancel();
        			}
        		});
        		
        		AlertDialog alert11 = builder1.create();
                alert11.show();
        	}
       	});
    }
   
	//////////////*********** KEN make this checkTaskRunning a dialogbox with only "OK" button ************////////////////////
    private void checkTaskRunning() {
    	int index = PieScheduleController.tempIndex;
    	AlertDialog.Builder builder = new AlertDialog.Builder(context);
    	if(pieSchedule.getSlice(index).getRemTime().totalInSec() == 0){
            builder.setTitle("Done");
    	}
    	else{
    		builder.setTitle("To do");
    	}
        builder.setCancelable(true);
        String strRemTime = pieSchedule.getSlice(index).getRemTime().toString();
        if(strRemTime.equals("-1:-1:-1")){
        	strRemTime = "";
        }
        builder.setMessage("Task: " + pieSchedule.getSlice(index).getTask().getName()+"\n" + "Remaining Time: " + strRemTime);
        builder.setPositiveButton("Okay", new DialogInterface.OnClickListener(){
	        @Override
	        public void onClick(DialogInterface dialog, int id){
	        	dialog.cancel();
	        }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener(){
        	@Override
            public void onClick(DialogInterface dialog, int id){
        		dialog.cancel();
        	}
        });
        AlertDialog alert = builder.create();
        alert.show();
    }
    
    private void checkTaskNotRunning() {
    	int index = PieScheduleController.tempIndex;
    	AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("To do");
        builder.setCancelable(true);
        String strRemTime = pieSchedule.getSlice(index).getRemTime().toString();
        if(strRemTime.equals("-1:-1:-1")){
        	strRemTime = "";
        }
        builder.setMessage("Task: " + pieSchedule.getSlice(index).getTask().getName()+"\n" + "Remaining Time: " + strRemTime);
        builder.setPositiveButton("Okay", new DialogInterface.OnClickListener(){
	        @Override
	        public void onClick(DialogInterface dialog, int id){
	        	dialog.cancel();
	        }
        });
        builder.setNegativeButton("Delete", new DialogInterface.OnClickListener(){
        	@Override
            public void onClick(DialogInterface dialog, int id){
        		deleteTask();
        		dialog.cancel();
        	}
        });
        AlertDialog alert = builder.create();
        alert.show();
    }
    
    private void deleteTask(){
    	int index = PieScheduleController.tempIndex;
    	AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
		builder1.setMessage("Are you sure you want to delete "+pieSchedule.getSlice(index).getTask().getName()+"?");
		builder1.setCancelable(true);
		
		builder1.setPositiveButton("Yes",
				new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				PieScheduleController.deleteTask(pieSchedule);
        		initColors();
				drawPieSchedule();
			}
		});
		
		builder1.setNegativeButton("No",
				new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});
		
		AlertDialog alert11 = builder1.create();
        alert11.show();
    }
    
    /**
     * addButtonOnClickListeners
     *  - Called when addButton is clicked. Adds user input task to the pie schedule.
     * @since 2015-02-27
     * @return void
     * @param void 
     */
	private void addButtonOnClickListeners(){
		addButton.setOnTouchListener(new OnTouchListener(){
            @Override
            public boolean onTouch (View v, MotionEvent event)
            {
            	int x = (int)event.getX();
	            int y = (int)event.getY();
	            
	    		Bitmap bitmap = getBitmapFromView(v);
	    		int color = bitmap.getPixel(x, y);
				if(color != Color.parseColor("#FFFFE7")  &&  color != Color.parseColor("#F5B64B")){
					return false;
				}
				/*if(event.getAction() == MotionEvent.ACTION_DOWN){
					addButton.setBackground(getResources().getDrawable(R.drawable.addbutton_small_pressed2));
					return true;
				}*/
				if(event.getAction() == MotionEvent.ACTION_UP){
					//addButton.setBackground(getResources().getDrawable(R.drawable.addbutton_small_pressed2));
					if(pieSchedule.getSize() == 10){
						Toast.makeText(getApplicationContext(), "You have reached the maximum number of tasks!", Toast.LENGTH_SHORT).show();
	 	                return true;
					}
	        		AlertDialog.Builder builder1 = new AlertDialog.Builder(v.getContext());
	        		inputText = new EditText(v.getContext());
	        		builder1.setTitle("New task:");
	        		builder1.setView(inputText);
	        		
	        		builder1.setCancelable(true);
	        		builder1.setPositiveButton("Okay",
	        				new DialogInterface.OnClickListener() {
	        			public void onClick(DialogInterface dialog, int id) {
	        			}
	        		});
	        		
	        		builder1.setNegativeButton("Cancel",
	        				new DialogInterface.OnClickListener() {
	        			public void onClick(DialogInterface dialog, int id) {
	        				dialog.cancel();
	        			}
	        		});
	        		
	        		final AlertDialog alert = builder1.create();
	        		alert.show(); 
	        		
	        		alert.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener()
	        	      {            
	        	          @Override
	        	          public void onClick(View v)
	        	          {
	        	              /* Do stuff, possibly set wantToCloseDialog to true then... */
	        					addButtonOnClickListeners();
	        					String strTask = inputText.getText().toString();
	        					if (!strTask.equals("")){
	        						PieScheduleController.tempTask = new Task(strTask);
	        						chooseColor();
	        						alert.dismiss();
	        					}
	        					else
	        						Toast.makeText(getApplicationContext(), "Please enter task", Toast.LENGTH_SHORT).show();
	        	          }
	        	      });
	        		return true;
            	}
				return false;
        	}
       	});
    }

	/**
     * startButtonOnClickListeners
     *  - Called when startButton is clicked. Starts the count down timer.
     * @since 2015-02-10
     * @return void
     * @param void 
     */
    private void startButtonOnClickListeners(){
         startButton.setOnClickListener(new ImageButton.OnClickListener(){
            @Override
              public void onClick(View view){
                   if(pieSchedule.isReadyToStart()){
                        //countDownToZero();
                        //startCountDownToZero();
                   } 
              }    
         });
    }
    /**
     * initColors
     *  - Checks which colors are available when adding task.
     * @since 2015-02-27
     * @return void
     * @param void 
     */
    private void initColors(){
    	int numColors = 12;
    	colors = new int[numColors];

    	colors[0] = Color.parseColor("#DBFF76"); 
    	colors[1] = Color.parseColor("#CFFFB0");
    	colors[2] = Color.parseColor("#C3D898");
        colors[3] = Color.parseColor("#4E7144"); 
    	colors[4] = Color.parseColor("#F79F79");
    	colors[5] = Color.parseColor("#C4E7D4");
    	colors[6] = Color.parseColor("#177E89");
    	colors[7] = Color.parseColor("#08605F");
    	colors[8] = Color.parseColor("#E99B9B");
    	colors[9] = Color.parseColor("#D0939F");
    	colors[10] = Color.parseColor("#B9C0DA");
    	colors[11] = Color.parseColor("#ABA5DA");
    	
    	isColorTaken = new boolean[numColors];
    	Arrays.fill(isColorTaken, false);
    	
    	int numSlices = pieSchedule.getSize();
    	for(int i = 0; i< numSlices; i++){
    		markColorTaken(pieSchedule.getSlice(i).getColor());
    	}
    }
    /**
     * markColorTaken
     *  - sets isColorTaken[i] to true when a color is used when adding a task
     * @since 2015-02-27
     * @return void
     * @param color (int)
     */
    private void markColorTaken(int color){
    	for(int i = 0; i<colors.length; i++){
    		if(colors[i] == color){
    			isColorTaken[i] = true;
    			break;
    		}
    	}
    }
    /**
     * chooseColor
     *  - Called when adding a task to let user pick a color 
     * @since 2015-02-27
     * @return void
     * @param void 
     */
	private void chooseColor() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
	
        /* Prepare grid view */
        GridView gridView = new GridView(context);
        
        List<String> mList = new ArrayList<String>();
        final int numColors = 12;
        for(int i = 0; i<numColors; i++){
        	if(isColorTaken[i])
        		mList.add("X");
        	else
        		mList.add("");
        }
        
        gridView.setAdapter(new ArrayAdapter(context, android.R.layout.simple_list_item_1, mList) {
        	@Override
        	public View getView(int position, View convertView, ViewGroup parent) {
        	    View view = super.getView(position, convertView, parent);
        	    for(int i = 0; i< numColors; i++){
        	    	view.setBackgroundColor(colors[position]);
        	    }
        	    return view;
        	  }
        });
        
        gridView.setNumColumns(4);
        
        /* Set grid view to alertDialog */
        builder.setView(gridView);
        builder.setTitle("Choose color: ");
        
        final  AlertDialog alert = builder.create();
        alert.show();
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {		        	
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            	if(isColorTaken[position]){
            		Toast.makeText(getApplicationContext(), "Choose a different color!", Toast.LENGTH_SHORT).show();
            	}else{
	            	markColorTaken(colors[position]);
	            	PieScheduleController.addTask(pieSchedule, colors[position]);
					drawPieSchedule();
					//addButton.setBackground(getResources().getDrawable(R.drawable.addbutton_small));
	          		alert.dismiss();
            	}
            }    
        });
    }
    
    /**
     * setTimeButtonOnClickListeners
     *  - Called when setTimeButton has been clicked. Lets user choose between
     *    setting start-end time or setting duration.
     * @since 2015-02-06
     * @param void
     * @return void
     */
    private void setTimeButtonOnClickListeners(){
         setTimeButton.setOnClickListener(new ImageButton.OnClickListener(){
            @Override
              public void onClick(View view){    
                   final CharSequence[] timeChoice = {" Set Start-End Time "," Set Duration "};
                   AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                    builder.setTitle("Choose type on time input:");
                   builder.setItems(timeChoice, new DialogInterface.OnClickListener(){
                      @Override
                        public void onClick(DialogInterface dialog, int item){
                             switch(item){
                             case 0:
                                  /* Set Start and End Time is selectSliceed */
                                  dialog.dismiss();
                                  setStartTime();
                                  break;
                             case 1:
                                  /* Duration is selectSliceed */
                                  dialog.dismiss();
                                  setDuration();
                                  break;
                             }
                             dialog.dismiss();
                        }
                   });
                   AlertDialog alert = builder.create();
                   alert.show();
              }
         });
    }
    
    /**
     * setStartTime
     *  - Set the start time of your Pie Schedule. Automatically calls {@link #setEndTime()}.
     * @since 2015-02-06
     * @param void
     * @return void
     */
    public void setStartTime(){
         AlertDialog.Builder builder = new AlertDialog.Builder(context);
         builder.setTitle("Set Time Start:");
         timePicker = new TimePicker(context);
         timePicker.setIs24HourView(true);
         timePicker.setCurrentHour(0);
         timePicker.setCurrentMinute(0);
         builder.setView(timePicker);
         builder.setPositiveButton("Okay", new DialogInterface.OnClickListener(){
            @Override
              public void onClick(DialogInterface dialog, int id){
                   pieSchedule.setStartTime(new Time(timePicker.getCurrentHour(), timePicker.getCurrentMinute(), 0));
                   dialog.cancel();
                   setEndTime();
              }
         });
         builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener(){
            @Override
              public void onClick(DialogInterface dialog, int id){
                   dialog.cancel();
              }
         });
         AlertDialog alert = builder.create();
         alert.show();
    }
    
    /**
     * setEndTime
     *  - Set the end time of your Pie Schedule.
     * @since 2015-02-06
     * @param void
     * @return void
     */
    public void setEndTime(){
    	AlertDialog.Builder builder = new AlertDialog.Builder(context);
         builder.setTitle("Set Time End:");
         timePicker = new TimePicker(context);
         timePicker.setIs24HourView(true);
         timePicker.setCurrentHour(0);
         timePicker.setCurrentMinute(0);
         builder.setView(timePicker);
         builder.setPositiveButton("Okay", new DialogInterface.OnClickListener(){
            @Override
              public void onClick(DialogInterface dialog, int id){
                 pieSchedule.setEndTime(new Time(timePicker.getCurrentHour(), timePicker.getCurrentMinute(), 0));
                 pieSchedule.setRemTime();
                   chronometer.setText("" + timeFormat.format(pieSchedule.getRemTime().totalInMilliSec()));
                   PieScheduleController.allocateTime(pieSchedule);
                   dialog.cancel();
              }
         });
         builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener(){
            @Override
              public void onClick(DialogInterface dialog, int id){
                 pieSchedule.setStartTime(new Time(-1,-1,-1));
                   dialog.cancel();
              }
         });
         AlertDialog alert = builder.create();
         alert.show();
    }
    
    /**
     * setDuration
     *  - Set the time duration of your Pie Schedule.
     * @since 2015-02-06
     * @param void
     * @return void
     */
    public void setDuration(){
    	AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Set Duration:");
        timePicker = new TimePicker(context);
         timePicker.setIs24HourView(true);
         timePicker.setCurrentHour(0);
         timePicker.setCurrentMinute(0);
         builder.setView(timePicker);
         builder.setPositiveButton("Okay", new DialogInterface.OnClickListener(){
            @Override
              public void onClick(DialogInterface dialog, int id){
                   pieSchedule.setStartTime(new Time(-1,-1,-1));
                 pieSchedule.setEndTime(new Time(-1,-1,-1));
                   pieSchedule.setRemTime(new Time(timePicker.getCurrentHour(), timePicker.getCurrentMinute(), 0));
                   chronometer.setText("" + timeFormat.format(pieSchedule.getRemTime().totalInMilliSec()));
                   PieScheduleController.allocateTime(pieSchedule);
                   dialog.cancel();
              }
         });
         builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener(){
            @Override
              public void onClick(DialogInterface dialog, int id){
                   dialog.cancel();
              }
         });
         AlertDialog alert = builder.create();
         alert.show();
    }
    
    public void drawPieSchedule(){
    	pie.draw(pieSchedule.getSlices());
		//ArrayList<Slice> arr = new ArrayList<Slice>();
		//pie.draw(arr);
		
//		int num = pieSchedule.getSize();
//		for(int i = 0; i < num; i++){
//
//			//SystemClock.sleep(1000);
//	    	 arr.add(pieSchedule.getSlice(i));
//	    	 pie.draw(arr);
			
	//	}

//      float sa = s.getStartAngle(), sw = s.getSweepAngle();
//      float degree = (float)5, rem = sw;
//      for(;rem>0;){
//      	canvas.drawArc(oval, sa, degree, true, circlePaint);
//      	//i++;
//      	sa = sa+degree;
//      	rem = rem - degree;
//      	if(rem<(float)10){
//      		degree = rem;
//      	}
    	
    }
    
    /**
     * countDownToZero
     *  - Sets the text of the Chronometer into the duration of the Pie Schedule.
     * @since 2015-02-06
     * @param void
     * @return void
     */
/*     private void countDownToZero(){
         chronometer = (Chronometer) findViewById(R.id.chronometer);
         Toast.makeText(getApplicationContext(), Long.toString(computeRemainingTime()/1000) + " seconds", Toast.LENGTH_SHORT).show();
         countDown = new CountDownTimer(computeRemainingTime(), 1000){
              public void onTick(long millisUntilFinished) {
                   chronometer.setText("" + timeFormat.format(millisUntilFinished));
              }
              public void onFinish(){
                   chronometer.setText("Time's up!");
              }
         };
    }
*/     
    /**
     * startCountDownToZero
     *  - Starts the countdown timer.
     * @since 2015-02-06
     * @param void
     * @return void
     */
/*     private void startCountDownToZero(){
         countDown.start(); 
    }
*/ 
}

